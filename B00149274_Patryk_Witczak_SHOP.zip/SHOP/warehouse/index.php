<?php include "../public/template/headerNoLogin.php"; ?>

<ul>
    <li>
        <a href="add.php"><strong>Create</strong></a> - add a product
    </li>
    <li>
        <a href="list.php"><strong>Update</strong></a> - edit a product
    </li>
</ul>

<?php include "../public/template/footer.php"; ?>
