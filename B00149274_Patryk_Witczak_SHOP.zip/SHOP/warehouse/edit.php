public/update-single.php
<?php
require "../src/clean.php";
$clean = new clean();

if (isset($_POST['submit']))
{
    try
    {
        require_once '../src/DBconnect.php';
        $productToUpdate =[
        "id"            => $id,
        "name"          => $clean -> cleaner($_POST['name']),
        "description"   => $clean -> cleaner($_POST['description']),
        "price"         => $clean -> cleaner($_POST['price']),
        ];

        $sql = "UPDATE products SET id = :id, name = :name, description = :description, price = :price, WHERE id = :id";
        $statement = $conn->prepare($sql);
        $statement->execute($productToUpdate);
    }
    catch(PDOException $error)
    {
        echo $sql . "<br>" . $error->getMessage();
    }
}
if (isset($_GET['id']))
{
    try
    {
        require_once '../src/DBconnect.php';
        $id = $_GET['id'];
        $sql = "SELECT * FROM products WHERE id = :id";
        $statement = $conn->prepare($sql);
        $statement->bindValue(':id', $id);
        $statement->execute();

        $product = $statement->fetch(PDO::FETCH_ASSOC);
    }

    catch(PDOException $error)
    {
        echo $sql . "<br>" . $error->getMessage();   }
    }
    else
    {
        echo "Something went wrong!";
        exit;
    }
?>

<?php require "../public/template/headerNoLogin.php"; ?>
<?php if (isset($_POST['submit']) && $statement) : ?>
<?php echo $clean -> cleaner($_POST['name']); ?> successfully updated.
<?php endif; ?>

<h2>Edit a user</h2>

<form method="post">
    <?php foreach ($product as $key => $value) : ?>
        <label for="<?php echo $key; ?>"><?php echo ucfirst($key); ?></label>
        <input type="text" name="<?php echo $key; ?>" id="<?php echo $key; ?>" value="<?php echo escape($value); ?>" <?php echo ($key === 'id' ? 'readonly' : null); ?>>
    <?php endforeach; ?>
    <input type="submit" name="submit" value="Submit">
</form>

<a href="index.php">Back to home</a>

<?php require "../public/template/footer.php"; ?>
