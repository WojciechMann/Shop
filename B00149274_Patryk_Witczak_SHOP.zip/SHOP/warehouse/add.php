<?php
if (isset($_POST['submit']))
{
    require "../src/clean.php";
    $clean = new clean();
    try
    {
        require_once '../src/DBconnect.php';

       $new_product = array(
            "name"          => $clean -> cleaner($_POST['name']),
            "description"   => $clean -> cleaner($_POST['description']),
            "price"         => $clean -> cleaner($_POST['price'])

        );

        $sql = sprintf("INSERT INTO %s (%s) values (%s)", "products",
            implode(", ", array_keys($new_product)),
            ":" . implode(", :", array_keys($new_product)));
        $statement = $conn -> prepare($sql);
        $statement->execute($new_product);
      /*  $sql = "INSERT INTO products (" . implode(', ', array_keys($new_product)) .")
        values (:". implode(', :', array_keys($new_product)).")";
        $statement = $conn->prepare($sql); */

    } catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    } }
require "../public/template/headerNoLogin.php";
if (isset($_POST['submit']) && $statement){
    echo $new_product['name']. ' successfully added';
}
?>

<h2>Add a product</h2>
<form method="post">
    <label for="name">Name</label>
    <input type="text" name="name" id="name" class="form-control mt-2" required>
    <label for="description">Description</label>
    <textarea id="description" name="description" class="form-control mt-2" required></textarea>
    <label for="price">Price</label>
    <input type="text" id="price" name="price" class="form-control mt-2" required pattern="^\d*(\.\d{0,2})?$">
    <input type="submit" value="Add Product">
</form>
<a href="index.php">Back to home</a>
<?php include "../public/template/footer.php"; ?>

