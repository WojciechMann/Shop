<?php
require_once '../src/DBconnect.php';
require "../src/clean.php";
$clean = new clean();

try
{
    $sql = "SELECT * FROM products";
    $statement = $conn->prepare($sql);
    $statement->execute();

    $products = $statement->fetchAll();
}
catch(PDOException $error)
{
    echo $sql . "<br>" . $error->getMessage();
}

require "../public/template/headerNoLogin.php";
?>

<h2>Product List</h2>

<table>
    <thead>
    <tr>
        <th>#</th>
        <th>Name</th>
        <th>Description</th>
        <th>Price</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($products as $product): ?>
        <tr>
            <td><?php echo $clean -> cleaner($product['id']); ?></td>
            <td><?php echo $clean -> cleaner($product['name']); ?></td>
            <td><?php echo $clean -> cleaner($product['description']); ?></td>
            <td><?php echo $clean -> cleaner($product['price']); ?></td>
            <td>
                <a href="edit.php?id=<?php echo $clean -> cleaner($product['id']); ?>">Edit</a> |
                <a href="delete.php?id=<?php echo $clean -> cleaner($product['id']); ?>" onclick="return confirm('Are you sure you want to delete this item?');">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<a href="add.php">Add New Product</a>
<a href="index.php">Back to home</a>

<?php require "../public/template/footer.php"; ?>
