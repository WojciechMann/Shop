<?php
require "../src/clean.php";
$clean = new clean();

if (isset($_GET["id"]))
{
    try
    {
        require_once '../src/DBconnect.php';
        $id = $clean->cleaner($_GET["id"]);

        $sql = "DELETE FROM products WHERE id = :id";
        $statement = $conn->prepare($sql);
        $statement->bindValue(':id', $id);
        $statement->execute();

        $success = "Name ". $id. " successfully deleted";
    }
    catch(PDOException $error)
    {
        echo $sql . "<br>" . $error->getMessage();
    }
}
try
{
    require_once '../src/DBconnect.php';

    $sql = "SELECT * FROM products";

    $statement = $conn->prepare($sql);
    $statement->execute();

    $result = $statement->fetchAll();
}
catch(PDOException $error)
{
    echo $sql . "<br>" . $error->getMessage();
}
?>
<?php require "../public/template/headerNoLogin.php"; ?>

<h2>Delete Product</h2>

<?php if ($success): ?>
    <p><?php echo $success; ?></p>
<?php endif; ?>

<table>
    <thead>
    <tr>
        <th>#</th>
        <th>Name</th>
        <th>Description</th>
        <th>Price</th>
        <th>Delete</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row) : ?>
        <tr>
            <td><?php echo $clean -> cleaner($row["id"]); ?></td>
            <td><?php echo $clean -> cleaner($row["name"]); ?></td>
            <td><?php echo $clean -> cleaner($row["description"]); ?></td>
            <td><?php echo $clean -> cleaner($row["price"]); ?></td>
            <td><a href="delete.php?id=<?php echo $clean -> cleaner($row["id"]); ?>">Delete</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<a href="index.php">Back to home</a>

<?php require "../public/template/footer.php"; ?>
