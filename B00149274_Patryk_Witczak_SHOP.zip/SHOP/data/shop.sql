CREATE DATABASE shop;

USE shop;

CREATE TABLE users (
                       id INT AUTO_INCREMENT PRIMARY KEY,
                       username VARCHAR(50) NOT NULL UNIQUE,
                       password VARCHAR(255) NOT NULL,
                       email VARCHAR(100),
                       address TEXT
);

CREATE TABLE products (
                       id INT AUTO_INCREMENT PRIMARY KEY,
                       name VARCHAR(100),
                       description TEXT,
                       price DECIMAL(10, 2)
);
