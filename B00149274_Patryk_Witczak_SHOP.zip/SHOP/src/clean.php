<?php
class clean
{
    function cleaner($d)
    {
        $d = trim($d);
        $d = stripslashes($d);
        $d = htmlspecialchars($d, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
        return($d);
    }
}