<?php require_once('../template/headerNoLogin.php'); ?>
<link rel="stylesheet" type="text/css" href="css/signin.css">
    <title>Sign in</title>
</head>

<?php
require_once ('../src/DBconnect.php');
require('../src/clean.php');
$clean = new clean();

if(isset($_POST['Submit'])) {

    $cleanUserName = $clean -> cleaner($_POST['Username']);
    $cleanPassword = $clean -> cleaner($_POST['Password']);

    try {

        $sql = "SELECT * FROM users WHERE username = :username AND password = :password";

        $statement = $connection -> prepare($sql);
        $statement -> bindParam(':username', $cleanUserName, PDO::PARAM_STR);
        $statement -> bindParam(':password', $cleanPassword, PDO::PARAM_STR);
        $statement -> execute();

        if($statement -> rowCount() > 0) {

            $result = $statement -> fetch(PDO::FETCH_ASSOC);

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['Active'] = true;

            header("location:view_orders.php");
            exit;
        } else {
            echo "Invalid email or password. Please try again.";
        }
    } catch (PDOException $pdoex) {
        die("Error: ". $pdoex -> getMessage());
    }
}
?>

<body>
<div class="container">
    <form action="" method="post" name="Login_Form" class="form-signin">
        <h2 class="form-signin-heading">Please sign in</h2>
        <label for="inputUsername" >Username</label>
        <input name="Username" type="username" id="inputUsername" class="form-control" placeholder="Username" required autofocus>
        <label for="inputPassword">Password</label>
        <input name="Password" type="password" id="inputPassword" class="form-control" placeholder="Password" required>
        <div class="checkbox">
            <label>
                <input type="checkbox" value="remember-me"> Remember me
            </label>
        </div>
        <button name="Submit" value="Login" class="button" type="submit">Sign in</button>

    </form>
</div>
</body>
</html>
