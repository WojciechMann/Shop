<?php

if(isset($_POST['submit']))
{
    require "../src/clean.php";
    $clean = new clean();
    try {
        require_once ("../src/DBconnect.php");

        $new_user = array(
            "username" => $clean -> cleaner($_POST['username']),
            "password" => $clean -> cleaner($_POST['password']),
            "email"    => $clean -> cleaner($_POST['email']),
            "address"  => $clean -> cleaner($_POST['address']),
        );

        $sql = sprintf( "INSERT INTO %s (%s) VALUES (%s)", "users",
            implode(", ", array_keys($new_user)), ":" . implode(", :", array_keys($new_user)));

        $statement = $conn -> prepare($sql);
        $statement -> execute($new_user);
    } catch(PDOException $error) {
        echo $sql . "<br>". $error -> getMessage();
    }
}
require('../public/template/headerNoLogin.php');
if(isset($_POST['submit']) && $statement) {
    echo $new_user['firstname']. ' has been registered';
}
?>
    <link rel="stylesheet" type="text/css" href="css/signin.css">
    <title>Sign up</title>
    </head>

    <div class="form-control p-5">
        <form method="POST" class="">
            <h2 class="form-signin-heading">Sign Up</h2>
            <label for="username" class="form-label">Username</label>
            <input type="text" name="username" id="username" class="form-control mt-2" required />
            <label for="password" class="form-label">Password</label>
            <input type="text" name="password" id="password" class="form-control mt-2" required />
            <label for="email" class="form-label">Email Address</label>
            <input type="email" name="email" id="email" class="form-control mt-2" required />
            <label for="address" class="form-label">Age</label>
            <textarea id="address" name="address" class="form-control mt-2"></textarea>
            <input type="submit" name="submit" id="submit" value="Submit" class="btn form-control mt-2 btn-primary" />
        </form>
    </div>
    <a href="index.php">Back to home</a>
<?php include ("../public/template/footer.php");?>