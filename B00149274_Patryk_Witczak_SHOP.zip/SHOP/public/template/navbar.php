<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="contacts.php">Contact</a></li>
        <li><a href="signup.php">Signup</a></li>
    </ul>
</nav>