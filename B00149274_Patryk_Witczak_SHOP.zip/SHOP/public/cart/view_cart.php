<?php require_once('../template/headerNoLogin.php'); ?>

<?php
require_once '../src/DBconnect.php'; // Database connection file

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

function fetchProductDetails($id, $conn) {
    try {
        $sql = "SELECT name, price FROM products WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $error) {
        die("Error fetching product details: " . $error->getMessage());
    }
}

?>

</head>
<body>
<h2>Your Shopping Cart</h2>

<?php if (empty($_SESSION['cart'])): ?>
    <p>Your cart is empty.</p>
<?php else: ?>
    <table>
        <thead>
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total Price</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($_SESSION['cart'] as $product_id => $quantity): ?>
            <?php
            $product = fetchProductDetails($product_id, $conn);
            if ($product): // Check if product exists
                $totalPrice = $product['price'] * $quantity;
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                    <td>$<?php echo number_format($product['price'], 2); ?></td>
                    <td><?php echo $quantity; ?></td>
                    <td>$<?php echo number_format($totalPrice, 2); ?></td>
                    <td><a href="remove_from_cart.php?product_id=<?php echo $product_id; ?>&action=remove">Remove</a></td>
                </tr>
            <?php else: ?>
                <tr><td colspan="5">Product no longer available</td></tr>
            <?php endif; ?>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p><strong>Total Amount: $<?php echo number_format(array_sum(array_map(function ($product_id, $quantity) use ($conn) {
                $product = fetchProductDetails($product_id, $conn);
                return $product ? $product['price'] * $quantity : 0;
            }, array_keys($_SESSION['cart']), $_SESSION['cart'])), 2); ?></strong></p>
    <a href="checkout.php">Proceed to Checkout</a>
<?php endif; ?>

</body>
</html>
