<?php session_start();

if (!isset($_SESSION['cart']))
{
    $_SESSION['cart'] = [];
}

if (isset($_POST['product_id']) && isset($_POST['quantity']))
{
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);

    if ($quantity > 0)
    {
        // Check if the product already exists in the cart
        if (isset($_SESSION['cart'][$product_id])) {
            // Update the quantity
            $_SESSION['cart'][$product_id] += $quantity;
        } else {
            // Add the product to the cart
            $_SESSION['cart'][$product_id] = $quantity;
        }
        $message = "Product added to cart successfully!";
    } else {
        $message = "Invalid product quantity.";
    }
} else {
    $message = "Product ID or quantity is missing.";
}

// Redirect to a page or output a message
echo $message; // In a real application, you'd likely want to redirect back to the product page or cart page
// header('Location: cart_page.php'); // Uncomment this line to enable redirection to the cart page after adding an item
exit;

