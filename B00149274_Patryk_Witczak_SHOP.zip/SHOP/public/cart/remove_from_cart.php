<?php
session_start(); // Start or resume the session

// Check if the cart exists in session, if not create it
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Check if the product ID is provided
if (isset($_GET['product_id'])) {
    $product_id = intval($_GET['product_id']);

    // Remove the product from the cart
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]); // Remove the item from the cart
        $_SESSION['message'] = "Item removed successfully.";
    } else {
        $_SESSION['message'] = "Item not found in cart.";
    }
} else {
    $_SESSION['message'] = "No product ID provided.";
}

// Redirect to the cart view page
header("Location: view_cart.php");
exit;
